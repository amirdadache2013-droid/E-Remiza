require("dotenv").config();
const { Client, GatewayIntentBits } = require("discord.js");
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const data = require("./data");

// ================= SERVER WWW =================
const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

server.listen(3000, () => {
  console.log("🚒 CAD ONLINE http://localhost:3000");
});

// ================= DISCORD =================
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

function send(msg) {
  const ch = client.channels.cache.get(process.env.CHANNEL_ID);
  if (ch) ch.send(msg);
}

// ================= SAFE UPDATE =================
function updateVehicle(name, status) {
  if (!name) return null;

  const v = data.unit.vehicles.find(x =>
    x.name && x.name.toLowerCase().includes(name.toLowerCase())
  );

  if (v) {
    v.status = status;
    io.emit("update", data);
  }

  return v;
}

// ================= WWW EVENTS =================
io.on("connection", (socket) => {
  console.log("📡 WWW connected");

  socket.on("alarmMulti", ({ vehicles, location }) => {
    if (!vehicles || vehicles.length === 0) return;

    vehicles.forEach(name => {
      const v = updateVehicle(name, "wyjazd");
      if (v) send(`🚨 ALARM: ${v.name}`);
    });

    send(`📍 Lokalizacja: ${location || "brak"}`);
  });

  socket.on("returnMulti", (vehicles) => {
    if (!vehicles || vehicles.length === 0) return;

    vehicles.forEach(name => {
      const v = updateVehicle(name, "wolny");
      if (v) send(`🔁 POWRÓT: ${v.name}`);
    });
  });
});

// ================= READY =================
client.once("ready", () => {
  console.log(`🤖 Zalogowano jako ${client.user.tag}`);
});

// ================= KOMENDY DISCORD =================
client.on("messageCreate", (message) => {
  if (message.author.bot) return;

  const args = message.content.split(" ");
  const cmd = args[0];

  const ch = client.channels.cache.get(process.env.CHANNEL_ID);

  if (cmd === "!alarm") {
    const vehicles = args.slice(1, -1);
    const location = args.slice(-1).join(" ") || "brak";

    vehicles.forEach(name => {
      const v = updateVehicle(name, "wyjazd");
      if (v) send(`🚨 ALARM: ${v.name}`);
    });

    ch.send(`📍 ${location}`);
  }

  if (cmd === "!powrot") {
    const vehicles = args.slice(1);

    vehicles.forEach(name => {
      const v = updateVehicle(name, "wolny");
      if (v) send(`🔁 POWRÓT: ${v.name}`);
    });
  }

  if (cmd === "!pojazdy") {
    ch.send(
      "🚒 POJAZDY:\n" +
      data.unit.vehicles.map(v => `• ${v.name} — ${v.status}`).join("\n")
    );
  }

  if (cmd === "!status") {
    ch.send(`📊 STATUS: ${data.unit.status}`);
  }

  if (cmd === "!radio") {
    const msg = args.slice(1).join(" ");
    ch.send(`📻 RADIO: ${message.author.username} - ${msg}`);
  }
});

client.login(process.env.TOKEN);