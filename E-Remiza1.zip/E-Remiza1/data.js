module.exports = {
  unit: {
    name: "OSP KSRG ŁOMIANKI",
    status: "wolna",
    vehicles: [
      { name: "Quad 669[M]02", status: "wolny" },
      { name: "GLM 669[M]51", status: "wolny" },
      { name: "SLRr 308[W]90", status: "wolny" },
      { name: "SLRr 317[W]90", status: "wolny" },
      { name: "SLBUS 669[M]54", status: "wolny" },
      { name: "GBA 317[W]21", status: "wolny" },
      { name: "GCBA 669[M]53", status: "wolny" },
      { name: "SRT 308[W]42", status: "wolny" }
    ]
  }
};