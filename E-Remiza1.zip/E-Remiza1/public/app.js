const socket = io();

// 🔊 SYRENA
const alarmSound = new Audio("/alarm.mp3");

socket.on("update", (data) => {
  document.getElementById("vehicleList").innerHTML =
    data.unit.vehicles.map(v => `
      <label>
        <input type="checkbox" value="${v.name}">
        ${v.name} — ${v.status}
      </label><br>
    `).join("");

  // 🔥 ALARM SOUND
  const isAlarm = data.unit.vehicles.some(v => v.status === "wyjazd");

  if (isAlarm) {
    alarmSound.play().catch(() => {});
  }
});

// 🚨 ALARM
function alarm() {
  const location = document.getElementById("location").value;

  const selected = [...document.querySelectorAll("input:checked")]
    .map(el => el.value);

  socket.emit("alarmMulti", {
    vehicles: selected,
    location
  });
}

// 🔁 POWRÓT
function powrot() {
  const selected = [...document.querySelectorAll("input:checked")]
    .map(el => el.value);

  socket.emit("returnMulti", selected);
}